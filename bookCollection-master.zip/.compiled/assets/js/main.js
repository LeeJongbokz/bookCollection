"use strict";

require("../scss/styles.scss");
//# sourceMappingURL=main.js.map